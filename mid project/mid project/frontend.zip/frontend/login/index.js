function showForm(formId) {
  document.getElementById("login-form").classList.add("hidden");
  document.getElementById("signup-form").classList.add("hidden");
  document.getElementById(formId).classList.remove("hidden");
}

document
  .getElementById("login-btn")
  .addEventListener("click", function (event) {
    event.preventDefault();

    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;

    if (email === "" || password === "") {
      showErrorMessage("Please fill in both fields.");
      return;
    }

    // إرسال الطلب إلى الـ API للتحقق من بيانات المستخدم
    fetch("http://localhost:5000/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // حفظ التوكن في الـ localStorage
          localStorage.setItem("token", data.token);
          showErrorMessage("Login successful!");
          window.location.href = "/Home.html";  // إعادة التوجيه إلى الصفحة الرئيسية
        } else {
          showErrorMessage(data.message || "Incorrect email or password.");
        }
      })
      .catch(error => {
        showErrorMessage("An error occurred while logging in.");
        console.error(error);
      });
  });
function showErrorMessage(message) {
  const errorMessageDiv = document.getElementById("error-message");
  errorMessageDiv.textContent = message;
  errorMessageDiv.classList.remove("hidden");

  setTimeout(() => {
    errorMessageDiv.classList.add("hidden");
  }, 3000);  
}

document
  .getElementById("signup-btn")
  .addEventListener("click", function (event) {
    event.preventDefault();

    const fullName = document.getElementById("full-name").value;
    const username = document.getElementById("username").value;
    const email = document.getElementById("signup-email").value;
    const phone = document.getElementById("phone-number").value;
    const password = document.getElementById("signup-password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    if (!fullName || !username || !email || !password || !confirmPassword) {
      showErrorMessage("Please fill in all required fields!");
      return;
    }

    if (password !== confirmPassword) {
      showErrorMessage("Password and Confirm Password do not match!");
      return;
    }

    // إرسال البيانات إلى الـ API لإنشاء الحساب
    fetch("http://localhost:5000/api/auth/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ fullName, username, email, phone, password }),
    })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          showSuccessMessage("Account created successfully!");
          showForm('login-form');  // الانتقال إلى نموذج تسجيل الدخول بعد إنشاء الحساب
        } else {
          showErrorMessage(data.message || "There was an error during registration.");
        }
      })
      .catch(error => {
        showErrorMessage("An error occurred while creating the account.");
        console.error(error);
      });
  });

  const token = localStorage.getItem("token");
  if (token) {
    try {
      const decoded = jwt_decode(token); 
      console.log(decoded);  
    } catch (error) {
      console.error("Invalid token");
    }
  } else {
    console.log("No token found");
  }
  
  
